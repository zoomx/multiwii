There is no difference in Configuration GUI caused by the Spektrum software in MultiWii.

I just happened to build the Spektrum code starting on a 1_8+ SVN version that does require a matching Configuration GUI. 